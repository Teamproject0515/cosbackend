import { Context } from 'react';

declare const ListContext: Context<{ dense?: boolean }>;
export default ListContext;
