import React from "react"

export const SidebarData=[
    {
        title:"New Arrivals",
        path:"/new",
        cName:"nav-text"
    },
    {
        title:"Women",
        path:"/women",
        cName:"nav-text"
    },
    {
        title:"Men",
        path:"/men",
        cName:"nav-text"
    },
    {
        title:"Kids & Baby",
        path:"/kids",
        cName:"nav-text"
    },
    {
        title:"Magazine",
        path:"/magazine",
        cName:"nav-text"
    }
]