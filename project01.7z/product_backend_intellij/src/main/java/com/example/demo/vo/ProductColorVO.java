package com.example.demo.vo;

import lombok.Data;

@Data
public class ProductColorVO {

    int product_seq;
    String product_title;
    int product_price;
    String product_img;
    String product_gender;
    String product_size;
    int product_stock;
    int product_saled;
    String product_category;
    String product_content;
    String color1;
    String color2;
    String color3;
    String color4;
    String color5;
    String color6;
    String color7;
    String color8;
    String color9;
    String color10;
    String color11;
    String color12;
}