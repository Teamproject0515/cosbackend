package com.example.demo.vo;

import lombok.Data;

@Data
public class UserColorVO {

    int id;
    String username;
    String password;
    String firstName;
    String lastName;
    int age;
    int salary;
    String color1;
    String color2;
    String color3;
    String color4;
    String color5;
    String color6;
    String color7;
    String color8;
    String color9;
    String color10;
    String color11;
    String color12;
}